﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kronos.BAL
{
    class EmployeeBLL
    {
        public string empID { get; set; }
        public string identityNumber { get; set; }
        public string firstName { get; set; }
        public string lastName { get; set; }
        public string address { get; set; }
        public string cellNumber { get; set; }
        public string telNumber { get; set; }
        public string taxNumber { get; set; }
        public string bankingDetails { get; set; }
        public string payPackage { get; set; }
        public bool empActive { get; set; }
        public DateTime dateEmployed { get; set; }
        public string empStatus { get; set; }


        public EmployeeBLL()
        { }


        public EmployeeBLL(string empID, string identityNumber, string firstName, string lastName, string address, string cellNumber
            , string telNumber, string taxNumber, string bankingDetails, string payPackage, bool empActive, DateTime dateEmployed, string empStatus)
        {
            this.empID = empID;
            this.identityNumber = identityNumber;
            this.firstName = firstName;
            this.lastName = lastName;
            this.address = address;
            this.cellNumber = cellNumber;
            this.telNumber = telNumber;
            this.taxNumber = taxNumber;
            this.bankingDetails = bankingDetails;
            this.payPackage = payPackage;
            this.empActive = empActive;
            this.dateEmployed = dateEmployed;
            this.empStatus = empStatus;
        
        
        
        }



    }

    
}
